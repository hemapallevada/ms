package com.simActivationProject.simMS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.simActivationProject.simMS.entity.SimDetails;
import com.simActivationProject.simMS.entity.SimOffers;
import com.simActivationProject.simMS.service.SimDetailsServiceImpl;
import com.simActivationProject.simMS.service.SimOffersServiceImpl;
@EnableDiscoveryClient
@EnableEurekaClient
@SpringBootApplication
public class SimMsApplication implements CommandLineRunner{
	@Autowired
	SimDetailsServiceImpl detservice;
	@Autowired
	SimOffersServiceImpl offservice;
	@Autowired
	public static void main(String[] args) {
		SpringApplication.run(SimMsApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {

		SimDetails ob1=new SimDetails(1l,"1234567891","1234567891234","active");
		SimDetails ob2=new SimDetails(2l,"1234567892","1234567891235","inactive");
		detservice.addSim(ob1);
		detservice.addSim(ob2);
	
		SimOffers of1=new SimOffers(1l,100,100,120,10,"Free calls and data",1);
		SimOffers of2=new SimOffers(2l,150,50,100,15,"Free calls and data",2);
		offservice.addSim(of1);
		offservice.addSim(of2);
		System.out.println("Run...........");
		
	}
}
