package com.simActivationProject.simMS.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simActivationProject.simMS.entity.SimOffers;
import com.simActivationProject.simMS.repository.SimOffersRepository;
@Service("simOffersService")
public class SimOffersServiceImpl implements SimOffersService {
	@Autowired
	SimOffersRepository simOffersRepoObj;
	public SimOffers addSim(SimOffers ob) {
		return simOffersRepoObj.saveAndFlush(ob);
	}
	public List<SimOffers> getAllSimOffers(){
		return simOffersRepoObj.findAll();
	}
	public SimOffers getSimById(long id) {
		Optional<SimOffers> ob= simOffersRepoObj.findById(id);
		if(ob.isEmpty())
			return null;
		return ob.get();
		
	}
	public void deleteSim(SimOffers emp) {
		simOffersRepoObj.delete(emp);
	}
}

	