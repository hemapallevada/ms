package com.simActivationProject.simMS.service;

import java.util.List;

import com.simActivationProject.simMS.entity.SimDetails;

public interface SimDetailsService {
public List<SimDetails> checkNum(String s1,String s2);
String updateSimStatus(Long id);
}
