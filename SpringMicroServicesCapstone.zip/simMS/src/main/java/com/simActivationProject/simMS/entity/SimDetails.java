package com.simActivationProject.simMS.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
@Entity
@Table(name="SimDetails")
public class SimDetails {
@Id
private long simId;
@Pattern(regexp="[0-9]{10}",message="invalid Service number")
private String serviceNumber;
@Pattern(regexp="[0-9]{13}",message="invalid Sim number")
private String simNumber;
private String simStatus;
public SimDetails(){}
public SimDetails(long simId,String serviceNumber, String simNumber,String simStatus){
	this.simId=simId;
	this.serviceNumber=serviceNumber;
	this.simNumber=simNumber;
	this.simStatus=simStatus;
}
public long getSimId() {
	return simId;
}
public void setSimId(long simId) {
	this.simId = simId;
}
public String getServiceNumber() {
	return serviceNumber;
}
public void setServiceNumber(String serviceNumber) {
	this.serviceNumber = serviceNumber;
}
public String getSimNumber() {
	return simNumber;
}
public void setSimNumber(String simNumber) {
	this.simNumber = simNumber;
}
public String getSimStatus() {
	return simStatus;
}
public void setSimStatus(String simStatus) {
	this.simStatus = simStatus;
}
public SimDetailsDTO simToDto(SimDetails sim) {
	SimDetailsDTO ob=new SimDetailsDTO();
	ob.setServiceNumber(sim.getServiceNumber());
	ob.setSimId(sim.getSimId());
	ob.setSimNumber(sim.getSimNumber());
	ob.setSimStatus(sim.getSimStatus());
	return ob;
			
}

}




