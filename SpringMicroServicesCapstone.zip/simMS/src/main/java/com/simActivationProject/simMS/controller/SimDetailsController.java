package com.simActivationProject.simMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

//import com.simactivation.exception.ResourceNotFoundException;
import com.simActivationProject.simMS.entity.SimDetails;
import com.simActivationProject.simMS.entity.SimOffers;
import com.simActivationProject.simMS.service.SimDetailsServiceImpl;
@RestController
@Validated
@RequestMapping("/simdetails")
public class SimDetailsController {
@Autowired
SimDetailsServiceImpl simObj;
@Autowired
SimOffersController simOffObj;
@PostMapping(value="/validateSim/{sNum}/{servNum}")
public String validateSim(@PathVariable("sNum") String simNum, @PathVariable("servNum") String servNum) throws Exception {
	System.out.println("Entered validate Sim.........");
	return simObj.validateSim(simNum,servNum);	
		
}
@GetMapping(value="/currentSim")
public SimDetails getCurrentSim() {
	return simObj.getCurrentSim();
}
@GetMapping(value="/getcurrentSimId")
public long getCurrentSimId()  {
	return simObj.getCurrentSim().getSimId();
}
@GetMapping(value="/setActiveStatus")
public String setSimActiveStatus() {
return simObj.setSimToActiveStatus();
}
}
