package com.simActivationProject.simMS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.simActivationProject.simMS.entity.SimOffers;
public interface SimOffersRepository extends JpaRepository<SimOffers,Long> {

}
