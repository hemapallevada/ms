package com.simActivationProject.simMS.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SimOffers")
public class SimOffers {
	@Id
private long offerId;
private int callQty;
private int cost;
private int dataQty;
private int duration;
private String offerName;
private long simId;
public SimOffers(){}
public SimOffers(long offerId, int callQty,int cost,int dataQty,int duration,String offerName,long simId){
	this.offerId=offerId;
	this.callQty=callQty;
	this.cost=cost;
	this.dataQty=dataQty;
	this.duration=duration;
	this.offerName=offerName;
	this.simId=simId;
}
public long getOfferId() {
	return offerId;
}
public void setOfferId(long offerId) {
	this.offerId = offerId;
}
public int getCallQty() {
	return callQty;
}
public void setCallQty(int callQty) {
	this.callQty = callQty;
}
public int getCost() {
	return cost;
}
public void setCost(int cost) {
	this.cost = cost;
}
public int getDataQty() {
	return dataQty;
}
public void setDataQty(int dataQty) {
	this.dataQty = dataQty;
}
public int getDuration() {
	return duration;
}
public void setDuration(int duration) {
	this.duration = duration;
}
public String getOfferName() {
	return offerName;
}
public void setOfferName(String offerName) {
	this.offerName = offerName;
}
public long getSimId() {
	return simId;
}
public void setSimId(long simId) {
	this.simId = simId;
}
public SimOffersDTO simToDto(SimOffers sim) {
	SimOffersDTO ob=new SimOffersDTO();
	ob.setCallQty(sim.getCallQty());
	ob.setCost(sim.getCost());
	ob.setDataQty(sim.getDataQty());
	ob.setDuration(sim.getDuration());
	ob.setOfferId(sim.getOfferId());
	ob.setOfferName(sim.getOfferName());
	ob.setSimId(sim.getSimId());
	return ob;
}
}
