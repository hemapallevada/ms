package com.simActivationProject.simMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simActivationProject.simMS.entity.SimOffers;
import com.simActivationProject.simMS.service.SimOffersServiceImpl;
@RestController
@Validated
@RequestMapping("/simoffers")
public class SimOffersController {
	@Autowired
	SimOffersServiceImpl simObj;
	public SimOffers getOffers(Long id) {
		// TODO Auto-generated method stub
		return simObj.getSimById(id);
	}

}
