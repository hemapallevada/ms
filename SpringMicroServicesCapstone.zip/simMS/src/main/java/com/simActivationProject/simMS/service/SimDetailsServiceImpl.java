package com.simActivationProject.simMS.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simActivationProject.simMS.controller.SimOffersController;
import com.simActivationProject.simMS.entity.SimDetails;
import com.simActivationProject.simMS.repository.SimDetailsRepository;
import com.simActivationProject.simMS.entity.SimOffers;


@Service("simDetailsService")
public class SimDetailsServiceImpl implements SimDetailsService{
	@Autowired
	SimDetailsRepository simDetailsRepoObj;
	@Autowired
	SimOffersController simOffObj;
	
	SimDetails curSimObj;
	public SimDetails addSim(SimDetails ob) {
		curSimObj=ob;
		return simDetailsRepoObj.saveAndFlush(ob);
	}
	public List<SimDetails> getAllSimDetails(){
		return simDetailsRepoObj.findAll();
	}
	public SimDetails getSimById(long id) {
		Optional<SimDetails> ob= simDetailsRepoObj.findById(id);
		if(ob.isEmpty())
			return null;
		return ob.get();
		
	}
	public void deleteSim(SimDetails emp) {
		simDetailsRepoObj.delete(emp);
	}
	public List<SimDetails> checkNum(@Valid @Pattern(regexp="[0-9]{13}",message="Invalid SIM Number")String s1,@Valid @Pattern(regexp="[0-9]{10}",message="Invalid Service Number")String s2){
		return simDetailsRepoObj.findBySimNumberServNumber(s1,s2);
	}
public String updateSimStatus(Long id) {
	SimDetails sdObj=getSimById(id);
		if(sdObj==null) {
			return "No id exists";
		}
		sdObj.setSimStatus("active");
		return "Activated Successfully";
	}

public SimDetails getCurrentSim() {
	return curSimObj;
}
public String setSimToActiveStatus() {
	if(curSimObj.getSimStatus().equalsIgnoreCase("inactive")) {
		
		curSimObj.setSimStatus("Active");
		SimDetails tempObj=addSim(curSimObj);
		if(tempObj==null)
			return "Something went wrong.....";
		else
		{
			
			return "Successfully Activated";
		}
	}
	else {
		return "Sim is already active";
	}
}





public String validateSim(String simNum,String servNum) {
List<SimDetails> simdet=checkNum(simNum,servNum);
if(simdet.size()==0)
	return  "Invalid SIM number/Invalid Service Number";
else {
	if(simdet.get(0).getSimStatus().equalsIgnoreCase("active")) {
		return "Sim is already active";
	}
	else {
	
	SimOffers allOof=simOffObj.getOffers(simdet.get(0).getSimId());
	curSimObj=simdet.get(0);
	return Long.toString(allOof.getSimId())+" "+Long.toString(allOof.getCallQty())+" "+Long.toString(allOof.getCost())+" "+Long.toString(allOof.getDataQty())+" "+Long.toString(allOof.getDuration())+" "+allOof.getOfferName()+" "+Long.toString(allOof.getOfferId());
}
}

}
}
