package com.simActivationProject.simMS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.simActivationProject.simMS.entity.SimDetails;
public interface SimDetailsRepository extends JpaRepository<SimDetails,Long>{
	@Query("select simDet from SimDetails simDet where simDet.simNumber =:a and simDet.serviceNumber=:b")
	List<SimDetails> findBySimNumberServNumber(@Param("a") String simNum,@Param("b") String servNum);
}
