package com.simActivationProject.customerMS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import com.simActivationProject.customerMS.entity.CustomerDTO;
import com.simActivationProject.customerMS.entity.CustomerAddressDTO;
import com.simActivationProject.customerMS.entity.CustomerIdentityDTO;
import com.simActivationProject.customerMS.service.CustomerAddressServieImpl;
import com.simActivationProject.customerMS.service.CustomerIdentityServiceImpl;
import com.simActivationProject.customerMS.service.CustomerServiceImpl;
@EnableCircuitBreaker
@EnableEurekaClient
@EnableDiscoveryClient
@SpringBootApplication
public class CustomerMsApplication implements CommandLineRunner{
	@Autowired
	CustomerServiceImpl custservice;
	@Autowired
	CustomerAddressServieImpl custaddservice;
	@Autowired
	CustomerIdentityServiceImpl custidenservice;
	public static void main(String[] args) {
		SpringApplication.run(CustomerMsApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
	CustomerDTO cus1=new CustomerDTO("1234567891234567","1990-12-12","smith@abc.com","Smith","John","Aadhar",1,1,"Karnataka");
	CustomerDTO cus2=new CustomerDTO("1234567891234568","1998-12-12","bob@abc.com","Bob","Sam","Aadhar",2,2,"Karnataka");
	custservice.addCustomer(cus1.dtoToCust(cus1));
	custservice.addCustomer(cus2.dtoToCust(cus2));
	CustomerAddressDTO cd1=new CustomerAddressDTO(1,"Jayanagar","Bangalore","786543","Karnataka");
	CustomerAddressDTO cd2=new CustomerAddressDTO(2,"Vijayanagar","Mysore","502465","Karnataka");
	custaddservice.addCustomerAdd(cd1.dtoToCustAdd(cd1));
	custaddservice.addCustomerAdd(cd2.dtoToCustAdd(cd2));
	CustomerIdentityDTO ci1=new CustomerIdentityDTO("1234567891234567","1990-12-12","Smith","John","smith@abc.com","Karnataka");
	CustomerIdentityDTO ci2=new CustomerIdentityDTO("1234567891234568","1998-12-12","Bob","Sam","bob@abc.com","Karnataka");
	custidenservice.addCustomerIden(ci1.dtoToCust(ci1));
	custidenservice.addCustomerIden(ci2.dtoToCust(ci2));
	System.out.println("Run...........");
	
}
}
