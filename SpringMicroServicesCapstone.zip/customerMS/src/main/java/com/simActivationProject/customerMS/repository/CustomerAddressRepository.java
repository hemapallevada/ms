package com.simActivationProject.customerMS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.simActivationProject.customerMS.entity.CustomerAddress;
public interface CustomerAddressRepository extends JpaRepository<CustomerAddress,Long>{

}
