package com.simActivationProject.customerMS.entity;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import com.sun.istack.NotNull;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
@Id
private String uniqueIdNumber;
private String dateOfBirth;
@Email
@Pattern(regexp="[a-zA-Z]+[@][a-zA-z]+[.][a-zA-z]{2,3}", message="Invalid Mail id")
private String emailAddress;
@NotEmpty(message="Firstname should not be empty")
private String firstName;
@NotEmpty(message="Lastname should not be empty")
private String lastName;
private String idType;
private long customerAddress_addressId;
private long simId;
private String state;

public Customer(){}
public Customer(String uniqueIdNumber,String dateOfBirth,String emailAddress, String firstName,String lastName,String idType,long customerAddress_addressId,long simId,String state){
	this.uniqueIdNumber=uniqueIdNumber;
	this.dateOfBirth=dateOfBirth;
	this.emailAddress=emailAddress;
	this.firstName=firstName;
	this.lastName=lastName;
	this.idType=idType;
	this.customerAddress_addressId=customerAddress_addressId;
	this.simId=simId;
	this.state=state;
	
}
public String getUniqueIdNumber() {
	return uniqueIdNumber;
}
public void setUniqueIdNumber(String uniqueIdNumber) {
	this.uniqueIdNumber = uniqueIdNumber;
}
public String getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(String dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getEmailAddress() {
	return emailAddress;
}
public void setEmailAddress(String emailAddress) {
	this.emailAddress = emailAddress;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getIdType() {
	return idType;
}
public void setIdType(String idType) {
	this.idType = idType;
}
public long getCustomerAddress_addressId() {
	return customerAddress_addressId;
}
public void setCustomerAddress_addressId(long customerAddress_addressId) {
	this.customerAddress_addressId = customerAddress_addressId;
}
public long getSimId() {
	return simId;
}
public void setSimId(long simId) {
	this.simId = simId;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public CustomerDTO custToDTO(Customer cust) {
	CustomerDTO ob=new CustomerDTO();
	ob.setCustomerAddress_addressId(cust.getCustomerAddress_addressId());
	ob.setDateOfBirth(cust.getDateOfBirth());
	ob.setEmailAddress(cust.getEmailAddress());
	ob.setFirstName(cust.getFirstName());
	ob.setLastName(cust.getLastName());
	ob.setIdType(cust.getIdType());
	ob.setSimId(cust.getSimId());
	ob.setState(cust.getState());
	ob.setUniqueIdNumber(cust.getUniqueIdNumber());
	return ob;
}
}
