package com.simActivationProject.customerMS.service;

import java.util.List;

import com.simActivationProject.customerMS.entity.Customer;

public interface CustomerService {
	List<Customer> findByMailDOB(String mail, String dob);
	List<Customer> findByName(String id, String fname, String lname);
}
