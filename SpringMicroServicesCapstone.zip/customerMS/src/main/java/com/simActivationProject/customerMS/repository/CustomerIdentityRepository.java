package com.simActivationProject.customerMS.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.simActivationProject.customerMS.entity.CustomerIdentity;
public interface CustomerIdentityRepository extends JpaRepository<CustomerIdentity,String> {
	@Query("select cus from CustomerIdentity cus where cus.uniqueIdNumber=:a and cus.firstName=:b and cus.lastName=:c")
	List<CustomerIdentity> findByIDName(@Param("a") String uINum,@Param("b") String fName,@Param("c") String lName);
}
