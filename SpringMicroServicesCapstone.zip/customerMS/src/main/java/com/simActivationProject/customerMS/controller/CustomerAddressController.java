package com.simActivationProject.customerMS.controller;

import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.simActivationProject.customerMS.entity.Customer;
import com.simActivationProject.customerMS.entity.CustomerAddress;

import com.simActivationProject.customerMS.service.CustomerAddressServieImpl;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@RestController
@Validated
@RequestMapping("/customerAddress")
public class CustomerAddressController {

	
	@Autowired
	CustomerAddressServieImpl custAddObj;
	@Autowired
	CustomerController custConObj;
	@Autowired
	CustomerIdentityController custIdenConObj;
	@HystrixCommand(fallbackMethod="updateDetailsFallBack")
	@PostMapping(value="/insert/{add}/{pincode}/{city}/{state}")
	public String updateDetails(@PathVariable("add") @Pattern(regexp="[a-zA-Z]{1,25}",message="Address should be maximum of 25 characters") String add, @PathVariable("pincode") @Pattern(regexp="[0-9]{6}", message="Pincode should be 6 digit number") String pincode,@PathVariable("city") @Pattern(regexp="[a-zA-Z ]+",message="Invalid city name") String city,@PathVariable("state") @Pattern(regexp="[a-zA-Z ]+",message="Invalid state name") String state) throws Exception {
		
		Customer curCust=custConObj.getCurrentCustomer();
		CustomerAddress tempCust=new CustomerAddress(curCust.getCustomerAddress_addressId(),add,city,pincode,state);
		curCust.setState(state);
		//CustomerIdentity custIden=custIdenConObj.getCustomerById(curCust.getUniqueIdNumber());
		if( custConObj.addCustomer(curCust)==null || custAddObj.updateDetails(tempCust)==null)
			return "Please check something is wrong!";
		return "Inserted/Updated Successfully";	
	}	
	public String updateDetailsFallBack(String add, String pincode, String city, String state) {
		return "Sorry!... Something went wrong! Please try after sometime";
	}
}
