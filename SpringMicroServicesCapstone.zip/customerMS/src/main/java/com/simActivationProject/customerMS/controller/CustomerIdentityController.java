package com.simActivationProject.customerMS.controller;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import java.net.URI;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.simActivationProject.customerMS.entity.Customer;
import com.simActivationProject.customerMS.entity.CustomerIdentity;
import com.simActivationProject.customerMS.service.CustomerIdentityServiceImpl;
@RestController
@Validated
@RequestMapping("/customerIdentity")
public class CustomerIdentityController {
	@Autowired
	CustomerIdentityServiceImpl custAddObj;
	@Autowired
	CustomerController custConObj;
	@Autowired
	DiscoveryClient discClient;
	@HystrixCommand(fallbackMethod="validateIdActiveStatusFallback")
	@PostMapping(value="/validateId/{aid}/{fname}/{lname}/{dob}")
	public String validateIdActivateStatus(@PathVariable("aid") @NotEmpty(message="Aadhar Should not be Empty") @Pattern(regexp="[0-9]{16}",message=" Aadhar Should be 16 digits") String aid,@PathVariable("fname") @NotEmpty(message="First name should not be empty") String fname, @PathVariable("lname") @NotEmpty(message="last name should not be empty") String lname,@PathVariable("dob") @NotEmpty(message="Date of Birth should not be empty") @Pattern(regexp="[0-9]{4}[-][0-9]{2}[-][0-9]{2}", message="Invalid DOB") String dob) {
		List<CustomerIdentity> retrived=custAddObj.findByIDName(aid,fname,lname);
		if(retrived.size()==0) {
			return "Invalid details";
		}
		Customer custObj=custConObj.getCurrentCustomer();
		if(fname.equals(custObj.getFirstName()) && lname.equals(custObj.getLastName()) && dob.equals(custObj.getDateOfBirth())) {
			List<ServiceInstance> serviceInsts=discClient.getInstances("sim");
			ServiceInstance simInst=serviceInsts.get(0);
			URI simUri=simInst.getUri();
			String st=new RestTemplate().getForObject(simUri+"/simdetails/setActiveStatus",String.class);
			return st;
		}
		else {
			return "Invalid details";
		}
	}
	public CustomerIdentity addCustomerIden(CustomerIdentity cust) {
		return addCustomerIden(cust);
	}
	public String validateIdActiveStatusFallback(String aaadharId,String fname,String lname,String dob) {
		return "Something went wrong....... We couldn't fetch some details. Please try later";
	}
	public CustomerIdentity getCustomerById(String id) {
		return getCustomerById(id);
	}
}


