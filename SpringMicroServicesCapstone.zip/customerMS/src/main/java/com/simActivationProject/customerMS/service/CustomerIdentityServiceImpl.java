package com.simActivationProject.customerMS.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simActivationProject.customerMS.entity.CustomerIdentity;
import com.simActivationProject.customerMS.repository.CustomerIdentityRepository;

@Service("customerIdentityService")
public class CustomerIdentityServiceImpl implements CustomerIdentityService{
	@Autowired
	CustomerIdentityRepository custIdenRepoObj;
	public CustomerIdentity addCustomerIden(CustomerIdentity ob) {
		return custIdenRepoObj.saveAndFlush(ob);
	}
	public CustomerIdentity getCustomerById(String id) {
		Optional<CustomerIdentity> ob= custIdenRepoObj.findById(id);
		if(ob.isEmpty())
			return null;
		return ob.get();
		
	}
	@Override
	public List<CustomerIdentity> findByIDName(String id,String fname, String lname){
		return custIdenRepoObj.findByIDName(id, fname, lname);
	}
}



