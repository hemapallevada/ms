package com.simActivationProject.customerMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

//import com.simactivation.exception.ResourceNotFoundException;
import com.simActivationProject.customerMS.entity.Customer;

import com.simActivationProject.customerMS.service.CustomerServiceImpl;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@RestController
@Validated
@RequestMapping("/customer")
public class CustomerController {
@Autowired
CustomerServiceImpl custObj;
@Autowired 
DiscoveryClient discClient;
@GetMapping(value="/currentCustomer")
public Customer getCurrentCustomer() {
	return custObj.getCurrentCustomer();
} 
public Customer addCustomer(Customer cs) {
	return custObj.addCustomer(cs);
}
@HystrixCommand(fallbackMethod="validateSimFallback")
@PostMapping(value="/validateDetails/{mail}/{dob}")
public String validateSim(@PathVariable("mail") @NotEmpty(message="Mail Id should not be empty")@Email(message="Invalid mail") String mail, @PathVariable("dob") @NotEmpty(message="Date of Birth should not be empty") @Pattern(regexp="[0-9]{4}[-][0-9]{2}[-][0-9]{2}", message="Invalid DOB") String dob) throws Exception {
	
	System.out.println("Entered validate Customer Mail and DOB.........");
	List<ServiceInstance> serviceInsts=discClient.getInstances("sim");
	ServiceInstance simInst=serviceInsts.get(0);
	URI simUri=simInst.getUri();
	long simId=new RestTemplate().getForObject(simUri+"/simdetails/getcurrentSimId",Long.class);
	return custObj.validateSim(simId,mail,dob);
		
}


public String validateSimFallback(String name, String mail) {
	return "Sorry...... We couldn't recieve required data please try after sometime";
}
@PostMapping(value="/validateNameDetails/{fname}/{lname}/{email}")
public String validateCustomerName(@PathVariable("fname") @Pattern( regexp="[a-zA-Z]{1,15}",message="Firstname should be a maximum length of 15 characters") String fname, @PathVariable("lname") @Pattern(regexp="[a-zA-Z]{1,15}", message="Last name should be a maximum length of 15 characters") String lname,@PathVariable("email")  String email) throws Exception {
	System.out.println("Entered validate CustomerName and Mail id.........");
	
	return custObj.validateCustomerName(fname,lname,email);
		
}
@PostMapping("/output")
public String returnOp() {
	return "Hello";
}
}

