package com.simActivationProject.customerMS.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.simActivationProject.customerMS.entity.Customer;
import com.simActivationProject.customerMS.repository.CustomerRepository;
@Service("customerService")
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	CustomerRepository custRepoObj;
	
	Customer curCustObj;
	@Override
	public List<Customer> findByMailDOB(String mail,String dob){
	
		return custRepoObj.findByMailDOB(mail,dob);
	}
	@Override
	public List<Customer> findByName(String id,String fname,String lname){
	
		return custRepoObj.findByName(id,fname,lname);
	}
	public Customer addCustomer(Customer ob) {
		return custRepoObj.saveAndFlush(ob);
	}
	public List<Customer> getAllCustomers(){
		return custRepoObj.findAll();
	}
	public Customer getCustomerById(String id) {
		Optional<Customer> ob= custRepoObj.findById(id);
		if(ob.isEmpty())
			return null;
		return ob.get();
		
	}
	public void deleteCustomer(Customer emp) {
		custRepoObj.delete(emp);
	}
	public String validateSim( long simId,String mail, String dob) throws Exception {		
		List<Customer> custlis=findByMailDOB(mail,dob);
		if(custlis.size()==0 ) {
			return "No request placed for you";
		}
		else {
			for(Customer cust:custlis) {
				if(cust.getSimId()==simId) {
					curCustObj=cust;
					return "Success";
				}
			
			}
			return "No request placed for you";
		}
			
	}
	
	public String validateCustomerName( String fname, String lname,String email) throws Exception {
		List<Customer> custlis=findByName(getCurrentCustomer().getUniqueIdNumber(),fname,lname);
		if(custlis.size()==0) {
			return "No Customer found for the provided details";
		}
		else {
			for(Customer c: custlis) {
				if(c.getEmailAddress().equalsIgnoreCase(email)) {
					curCustObj=c;
					return "Success";
				}
			}
			return "Invalid email details!!";
			
		}
			
	}
	
	public Customer getCurrentCustomer() {
		return curCustObj;
	} 
}

