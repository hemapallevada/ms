package com.simActivationProject.customerMS.service;

import java.util.List;

import com.simActivationProject.customerMS.entity.CustomerIdentity;

public interface CustomerIdentityService {
	List<CustomerIdentity> findByIDName(String id,String fname, String lname);
}
