package com.simActivationProject.customerMS.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simActivationProject.customerMS.entity.CustomerAddress;
import com.simActivationProject.customerMS.repository.CustomerAddressRepository;
@Service("customerAdressService")
public class CustomerAddressServieImpl implements CustomerAddressService{
	@Autowired
	CustomerAddressRepository custAddRepoObj;
public CustomerAddress updateDetails(CustomerAddress custAdd) {
	return custAddRepoObj.saveAndFlush(custAdd);
}
public CustomerAddress addCustomerAdd(CustomerAddress ob) {
	return custAddRepoObj.saveAndFlush(ob);
}
public List<CustomerAddress> getAllCustomers(){
	return custAddRepoObj.findAll();
}
public CustomerAddress getCustomerAddrById(Long id) {
	Optional<CustomerAddress> ob= custAddRepoObj.findById(id);
	if(ob.isEmpty())
		return null;
	return ob.get();
	
}


}


