package com.simActivationProject.customerMS.service;

import com.simActivationProject.customerMS.entity.CustomerAddress;

public interface CustomerAddressService {
public CustomerAddress updateDetails(CustomerAddress custAdd);
}
