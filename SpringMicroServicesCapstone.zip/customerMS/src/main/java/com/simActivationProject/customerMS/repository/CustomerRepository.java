package com.simActivationProject.customerMS.repository;

import java.util.List;
import com.simActivationProject.customerMS.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CustomerRepository extends JpaRepository<Customer,String>{
	@Query("select cus from Customer cus where cus.emailAddress=:a and cus.dateOfBirth=:b")
	List<Customer> findByMailDOB( @Param("a") String mail,@Param("b") String dob);
	@Query("select cus from Customer cus where cus.uniqueIdNumber=:id and cus.firstName=:a and cus.lastName=:b")
	List<Customer> findByName(@Param("id")String id,@Param("a") String fname,@Param("b") String lname);
}
