package com.simActivationProject.zipkin;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinApplicationTests {


	void contextLoads() {
	}

}
